<#assign myParentDir="service">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>  
package ${basepackage}.${table.classNameFirstLower}.service;

import ${basepackage}.${table.classNameFirstLower}.entity.${className};
import com.yang.spinach.frame.service.BaseService;


<#include "/copyright_class.include" >
public interface ${className}Service extends BaseService<${className}>{
	
}
