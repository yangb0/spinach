<#assign myParentDir="service.impl">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>  
package ${basepackage}.${table.classNameFirstLower}.service;


import ${basepackage}.${table.classNameFirstLower}.entity.${className};
import ${basepackage}.${table.classNameFirstLower}.service.${className}Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yang.spinach.frame.pagePlugin.Pagination;
import com.yang.spinach.frame.service.impl.BaseServiceImpl;

import ${basepackage}.${table.classNameFirstLower}.dao.${className}Dao;



<#include "/copyright_class.include" >
@Service("${classNameLower}Service")
public class ${className}ServiceImpl  extends BaseServiceImpl<${className}> implements ${className}Service {
	@Autowired
    private ${className}Dao ${classNameLower}Dao;
   
    
}
