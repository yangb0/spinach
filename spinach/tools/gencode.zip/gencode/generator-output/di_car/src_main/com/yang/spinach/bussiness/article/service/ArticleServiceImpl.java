package com.yang.spinach.bussiness.article.service;


import com.yang.spinach.bussiness.article.entity.Article;
import com.yang.spinach.bussiness.article.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yang.spinach.frame.pagePlugin.Pagination;
import com.yang.spinach.frame.service.impl.BaseServiceImpl;

import com.yang.spinach.bussiness.article.dao.ArticleDao;



/**
 * 
 * @author yang <Auto generate>
 * @version  2016-03-04 14:17:17
 * @see com.yang.spinach.bussiness.article.service.impl.Article
 */
@Service("articleService")
public class ArticleServiceImpl  extends BaseServiceImpl<Article> implements ArticleService {
	@Autowired
    private ArticleDao articleDao;
   
    
}
