package com.yang.spinach.bussiness.article.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import org.apache.commons.lang.StringUtils;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * 
 * @author yang <Auto generate>
 * @version  2016-03-04 14:17:17
 * @see com.yang.spinach.bussiness.article.entity.Article
 */
@Table(name = "t_article")
public class Article  implements Serializable{
	
	//columns START
	/**
	 * 文章ID
	 */
		@Id
	private Long articleId;
	/**
	 * folder_id
	 */
	private Long folderId;
	/**
	 * path
	 */
	private String path;
	/**
	 * 用户id
	 */
	private Long accountId;
	/**
	 * picture
	 */
	private String picture;
	/**
	 * 文章名称
	 */
	private String title;
	/**
	 * summary
	 */
	private String summary;
	/**
	 * 文章内容
	 */
	private String content;
	/**
	 * 浏览数
	 */
	private Integer viewCount;
	/**
	 * 评论数
	 */
	private Integer commentCount;
	/**
	 * 状态：0 隐藏 1 显示
	 */
	private String status;
	/**
	 * check
	 */
	private Integer check;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 更新时间
	 */
	private Date updateTime;
	//columns END 数据库字段结束
	
	

	//get and set
	public void setArticleId(Long articleId) {
	    
		this.articleId = articleId;
	}
	
	
	public Long getArticleId() {
		return this.articleId;
	}
	public void setFolderId(Long folderId) {
	    
		this.folderId = folderId;
	}
	
	
	public Long getFolderId() {
		return this.folderId;
	}
	public void setPath(String path) {
	    
		    if(StringUtils.isNotBlank(path)){
			 path=path.trim();
			}
		this.path = path;
	}
	
	
	public String getPath() {
		return this.path;
	}
	public void setAccountId(Long accountId) {
	    
		this.accountId = accountId;
	}
	
	
	public Long getAccountId() {
		return this.accountId;
	}
	public void setPicture(String picture) {
	    
		    if(StringUtils.isNotBlank(picture)){
			 picture=picture.trim();
			}
		this.picture = picture;
	}
	
	
	public String getPicture() {
		return this.picture;
	}
	public void setTitle(String title) {
	    
		    if(StringUtils.isNotBlank(title)){
			 title=title.trim();
			}
		this.title = title;
	}
	
	
	public String getTitle() {
		return this.title;
	}
	public void setSummary(String summary) {
	    
		    if(StringUtils.isNotBlank(summary)){
			 summary=summary.trim();
			}
		this.summary = summary;
	}
	
	
	public String getSummary() {
		return this.summary;
	}
	public void setContent(String content) {
	    
		    if(StringUtils.isNotBlank(content)){
			 content=content.trim();
			}
		this.content = content;
	}
	
	
	public String getContent() {
		return this.content;
	}
	public void setViewCount(Integer viewCount) {
	    
		this.viewCount = viewCount;
	}
	
	
	public Integer getViewCount() {
		return this.viewCount;
	}
	public void setCommentCount(Integer commentCount) {
	    
		this.commentCount = commentCount;
	}
	
	
	public Integer getCommentCount() {
		return this.commentCount;
	}
	public void setStatus(String status) {
	    
		    if(StringUtils.isNotBlank(status)){
			 status=status.trim();
			}
		this.status = status;
	}
	
	
	public String getStatus() {
		return this.status;
	}
	public void setCheck(Integer check) {
	    
		this.check = check;
	}
	
	
	public Integer getCheck() {
		return this.check;
	}
		/*
	public String getcreate_timeString() {
		return DateUtils.convertDate2String(FORMAT_CREATE_TIME, getcreate_time());
	}
	public void setcreate_timeString(String value) throws ParseException{
		setcreate_time(DateUtils.convertString2Date(FORMAT_CREATE_TIME,value));
	}*/
	
	public void setCreateTime(Date createTime) {
	    
		this.createTime = createTime;
	}
	
	
	public Date getCreateTime() {
		return this.createTime;
	}
		/*
	public String getupdate_timeString() {
		return DateUtils.convertDate2String(FORMAT_UPDATE_TIME, getupdate_time());
	}
	public void setupdate_timeString(String value) throws ParseException{
		setupdate_time(DateUtils.convertString2Date(FORMAT_UPDATE_TIME,value));
	}*/
	
	public void setUpdateTime(Date updateTime) {
	    
		this.updateTime = updateTime;
	}
	
	
	public Date getUpdateTime() {
		return this.updateTime;
	}
	
	public String toString() {
		return new StringBuffer()
			.append("articleId=").append(getArticleId()).append(",")
			.append("folderId=").append(getFolderId()).append(",")
			.append("path=").append(getPath()).append(",")
			.append("accountId=").append(getAccountId()).append(",")
			.append("picture=").append(getPicture()).append(",")
			.append("title=").append(getTitle()).append(",")
			.append("summary=").append(getSummary()).append(",")
			.append("content=").append(getContent()).append(",")
			.append("viewCount=").append(getViewCount()).append(",")
			.append("commentCount=").append(getCommentCount()).append(",")
			.append("status=").append(getStatus()).append(",")
			.append("check=").append(getCheck()).append(",")
			.append("createTime=").append(getCreateTime()).append(",")
			.append("updateTime=").append(getUpdateTime()).append(",")
			.toString();
	}
	
	
}

	
