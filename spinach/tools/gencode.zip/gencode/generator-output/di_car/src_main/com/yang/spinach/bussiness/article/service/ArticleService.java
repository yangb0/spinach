package com.yang.spinach.bussiness.article.service;

import com.yang.spinach.bussiness.article.entity.Article;
import com.yang.spinach.frame.service.BaseService;


/**
 * 
 * @author yang <Auto generate>
 * @version  2016-03-04 14:17:17
 * @see com.yang.spinach.bussiness.article.service.Article
 */
public interface ArticleService extends BaseService<Article>{
	
}
