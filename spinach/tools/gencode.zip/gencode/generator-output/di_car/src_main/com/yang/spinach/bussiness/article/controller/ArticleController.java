package  com.yang.spinach.bussiness.article.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


import com.yang.spinach.bussiness.article.entity.Article;
import com.yang.spinach.bussiness.article.service.ArticleService;


/**
 * 
 * @author yang <Auto generate>
 * @version  2016-03-04 14:17:17
 * @see com.yang.spinach.bussiness.article.article.Article
 */
@Controller
@RequestMapping(value="/article")
public class ArticleController {
	 @Autowired
	private ArticleService articleService;
	
	
}
