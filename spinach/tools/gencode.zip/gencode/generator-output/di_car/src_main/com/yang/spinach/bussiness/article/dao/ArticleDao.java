package com.yang.spinach.bussiness.article.dao;

import com.yang.spinach.bussiness.article.entity.Article;
import com.yang.spinach.frame.dao.MyMapper;

/**
 * 
 * @author yang <Auto generate>
 * @version  2016-03-04 14:17:17
 * @see com.yang.spinach.bussiness.article.dao.Article
 */
public interface ArticleDao extends MyMapper<Article> {
	
}
