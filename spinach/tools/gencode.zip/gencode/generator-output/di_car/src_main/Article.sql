
INSERT INTO t_menu values('t_article_list','Article管理', 'system_manager', null,'/article/list','1','是');
INSERT INTO t_menu values('t_article_update','修改Article', 't_article_list', null,'/article/update','0','是');
INSERT INTO t_menu values('t_article_look','查看Article', 't_article_list', null,'/article/look','0','是');
INSERT INTO t_menu values('t_article_export','导出Article', 't_article_list', null,'/article/list/export','0','是');
INSERT INTO t_menu values('t_article_delMulti','批量删除Article', 't_article_list', null,'/article/delMulti','0','是');
INSERT INTO t_menu values('t_article_delete','删除Article', 't_article_list', null,'/article/delete','0','是');
INSERT INTO t_menu values('t_article_upload','导入Article', 't_article_list', null,'/article/upload','0','是');
INSERT INTO `t_role_menu` VALUES ('t_article_list_admin', 'admin', 't_article_list');
INSERT INTO `t_role_menu` VALUES ('t_article_update_admin', 'admin', 't_article_update');
INSERT INTO `t_role_menu` VALUES ('t_article_look_admin', 'admin', 't_article_look');
INSERT INTO `t_role_menu` VALUES ('t_article_export_admin', 'admin', 't_article_export');
INSERT INTO `t_role_menu` VALUES ('t_article_delMulti_admin', 'admin', 't_article_delMulti');
INSERT INTO `t_role_menu` VALUES ('t_article_delete_admin', 'admin', 't_article_delete');
INSERT INTO `t_role_menu` VALUES ('t_article_upload_admin', 'admin', 't_article_upload');
