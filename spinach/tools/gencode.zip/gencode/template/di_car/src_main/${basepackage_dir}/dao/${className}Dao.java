<#assign myParentDir="dao">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>  
package ${basepackage}.dao;

import ${basepackage}.entity.${className};
import com.yang.spinach.frame.dao.MyMapper;

<#include "/copyright_class.include" >
public interface ${className}Dao extends MyMapper<${className}> {
	
}
